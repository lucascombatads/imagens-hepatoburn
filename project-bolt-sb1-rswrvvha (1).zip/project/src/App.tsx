import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Send, Image, Brush, Lightbulb, Search, Globe, Rocket, Settings, MessageCircle, Sun, Moon, Menu } from "lucide-react";

const translations = {
  pt: {
    chatIA: "Chat IA",
    googleAds: "Campanha Google Ads",
    settings: "Configurações",
    lightMode: "Modo Claro",
    darkMode: "Modo Escuro",
    helpText: "Como posso ajudar?",
    placeholder: "Digite sua pergunta...",
    processing: "Processando com a inteligência da GoatMind AI..."
  },
  en: {
    chatIA: "AI Chat",
    googleAds: "Google Ads Campaign",
    settings: "Settings",
    lightMode: "Light Mode",
    darkMode: "Dark Mode",
    helpText: "How can I help?",
    placeholder: "Type your question...",
    processing: "Processing with GoatMind AI intelligence..."
  },
  es: {
    chatIA: "Chat IA",
    googleAds: "Campaña de Google Ads",
    settings: "Configuraciones",
    lightMode: "Modo Claro",
    darkMode: "Modo Oscuro",
    helpText: "¿Cómo puedo ayudar?",
    placeholder: "Escribe tu pregunta...",
    processing: "Procesando con la inteligencia de GoatMind AI..."
  }
};

const ChatBubble = ({ message, isUser, darkMode }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.3 }}
    className={`max-w-[75%] px-4 py-3 rounded-2xl shadow-md text-sm md:text-base mb-2 ${
      isUser
        ? "bg-gradient-to-r from-[#7f00ff] to-[#00c6ff] text-white self-end ml-auto text-right"
        : darkMode
        ? "bg-[#1f1f2e] text-white self-start mr-auto text-left"
        : "bg-gray-300 text-black self-start mr-auto text-left"
    }`}
  >
    {message}
  </motion.div>
);

async function sendMessageToBackend(message) {
  try {
    const response = await fetch('http://127.0.0.1:8000/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prompt: message }),
    });

    const data = await response.json();
    return data.response;
  } catch (error) {
    console.error('Erro ao se conectar com o backend:', error);
    return 'Erro ao obter resposta.';
  }
}

export default function GoatMindAIPanel() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [language, setLanguage] = useState("pt");

  const bottomRef = useRef(null);
  const messagesContainerRef = useRef(null);

  const typeEffect = (text, callback) => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < text.length) {
        callback((prev) => prev + text.charAt(i));
        i++;
      } else {
        clearInterval(interval);
      }
    }, 25);
  };

  const handleSend = async () => {
    if (!input.trim() || isThinking) return;

    const userMessage = { text: input, isUser: true };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsThinking(true);

    try {
      const aiResponse = await sendMessageToBackend(input);
      let text = "";
      setMessages((prev) => [...prev, { text: "", isUser: false }]);

      typeEffect(aiResponse || "Desculpe, não consegui entender.", (val) => {
        text = val;
        setMessages((prev) => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].text = val;
          return newMessages;
        });
      });
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        { text: "Erro ao se comunicar com o servidor.", isUser: false }
      ]);
      console.error("Erro na API:", error);
    }

    setIsThinking(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleSend();
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const bgColor = darkMode ? "bg-[#0e0e1b] text-white" : "bg-white text-black";
  const sidebarColor = darkMode ? "bg-[#141428]" : "bg-gray-100";
  const inputBg = darkMode ? "bg-[#2a2a3d] text-white" : "bg-gray-200 text-black";
  const headerBg = darkMode ? "bg-[#0e0e1b] text-white" : "bg-white text-black";
  const hoverBg = darkMode ? "hover:bg-[#1f1f2e]" : "hover:bg-gray-300";
  const selectBg = darkMode ? "bg-[#2a2a3d] text-white" : "bg-gray-200 text-black";

  return (
    <div className={`min-h-screen flex ${bgColor}`}>      
      <div className={`flex items-center p-4 shadow-md w-full fixed top-0 z-20 ${headerBg}`}>
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="mr-4">
          <Menu size={24} />
        </button>
        <div className="text-2xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-[#7f00ff] to-[#00c6ff]">GoatMindAI</div>
      </div>
      <aside
        className={`w-64 ${sidebarColor} flex flex-col p-4 space-y-4 shadow-lg fixed top-0 bottom-0 left-0 z-10 transform ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} transition-transform duration-300`}
      >
        <button onClick={() => setSidebarOpen(false)} className="self-end p-2">✖</button>
        <button onClick={() => setActiveTab("chat")} className={`flex items-center gap-2 p-2 rounded-lg ${hoverBg}`}>
          <MessageCircle size={20} /> {translations[language].chatIA}
        </button>
        <button onClick={() => setActiveTab("ads")} className={`flex items-center gap-2 p-2 rounded-lg ${hoverBg}`}>
          <Rocket size={20} /> {translations[language].googleAds}
        </button>
        <button onClick={() => setActiveTab("config")} className={`flex items-center gap-2 p-2 rounded-lg ${hoverBg}`}>
          <Settings size={20} /> {translations[language].settings}
        </button>
        <button onClick={() => setDarkMode(!darkMode)} className="flex items-center gap-2 p-2 mt-8 rounded-lg bg-gradient-to-r from-[#7f00ff] to-[#00c6ff] text-white hover:opacity-90">
          {darkMode ? <Sun size={20} /> : <Moon size={20} />} {darkMode ? translations[language].lightMode : translations[language].darkMode}
        </button>
        <select
          onChange={(e) => setLanguage(e.target.value)}
          value={language}
          className={`p-2 rounded-lg ${selectBg}`}
        >
          <option value="pt">Português</option>
          <option value="en">English</option>
          <option value="es">Español</option>
        </select>
      </aside>
      <main className="flex-1 p-6 mt-12">
        {activeTab === "chat" && (
          <div className="flex flex-col h-full max-w-3xl mx-auto">
            <div className="text-xl font-semibold mb-4 text-center">{translations[language].helpText}</div>
            <div ref={messagesContainerRef} className="flex-1 overflow-y-auto flex flex-col-reverse mb-4">
              <div ref={bottomRef} />
              {[...messages].reverse().map((msg, idx) => (
                <ChatBubble key={idx} message={msg.text} isUser={msg.isUser} darkMode={darkMode} />
              ))}
            </div>
            <div className="flex gap-2 sticky bottom-0 py-4">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={translations[language].placeholder}
                className={`flex-1 rounded-2xl px-4 py-2 focus:outline-none ${inputBg}`}
              />
              <button
                onClick={handleSend}
                disabled={isThinking}
                className="bg-gradient-to-r from-[#7f00ff] to-[#00c6ff] text-white p-2 rounded-2xl hover:opacity-90"
              >
                {isThinking ? (
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
                  </svg>
                ) : (
                  <Send size={20} />
                )}
              </button>
            </div>
          </div>
        )}
        {activeTab === "ads" && (
          <div className="text-center text-xl font-semibold mt-10 text-gray-500">
            Em breve: Modo Campanha Google Ads ⚙️
          </div>
        )}
        {activeTab === "config" && (
          <div className="text-center text-xl font-semibold mt-10 text-gray-500">
            Em breve: Configurações da Plataforma 🔧
          </div>
        )}
      </main>
    </div>
  );
}