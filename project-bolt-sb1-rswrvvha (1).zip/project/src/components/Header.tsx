import React from 'react';
import { Brain } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm py-4 px-6">
      <div className="max-w-4xl mx-auto flex items-center">
        <Brain className="h-6 w-6 text-purple-500 mr-2" />
        <h1 className="text-xl font-semibold text-gray-800">
          GoatMind AI — <span className="text-purple-500">GPT-2 Local</span>
        </h1>
      </div>
    </header>
  );
};

export default Header;