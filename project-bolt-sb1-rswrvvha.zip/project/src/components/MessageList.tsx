import React from 'react';
import { Message } from '../types/chat';
import ThinkingIndicator from './ThinkingIndicator';

interface MessageListProps {
  messages: Message[];
  isThinking: boolean;
}

const MessageList: React.FC<MessageListProps> = ({ messages, isThinking }) => {
  return (
    <div className="space-y-4 py-2 px-1">
      {messages.map(message => (
        <div 
          key={message.id}
          className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
        >
          <div 
            className={`max-w-[80%] md:max-w-[70%] rounded-2xl px-4 py-3 ${
              message.sender === 'user' 
                ? 'bg-gray-200 text-gray-800 rounded-tr-none' 
                : 'bg-blue-100 text-gray-800 rounded-tl-none'
            }`}
          >
            <p className="whitespace-pre-wrap">{message.text}</p>
          </div>
        </div>
      ))}
      
      {isThinking && (
        <div className="flex justify-start">
          <div className="bg-blue-100 text-gray-800 rounded-2xl rounded-tl-none px-4 py-3">
            <ThinkingIndicator />
          </div>
        </div>
      )}
    </div>
  );
};

export default MessageList;