import React, { useState } from 'react';
import { Send, Trash2 } from 'lucide-react';

interface MessageInputProps {
  onSendMessage: (text: string) => void;
  onClearChat: () => void;
  disabled: boolean;
}

const MessageInput: React.FC<MessageInputProps> = ({ 
  onSendMessage, 
  onClearChat,
  disabled 
}) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSendMessage(message);
      setMessage('');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 p-3">
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <button
          type="button"
          onClick={onClearChat}
          className="p-2.5 text-gray-500 hover:text-red-500 transition-colors rounded-full hover:bg-gray-100"
          aria-label="Limpar Chat"
          title="Limpar Chat"
        >
          <Trash2 className="h-5 w-5" />
        </button>
        
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Digite uma mensagem..."
          className="flex-1 py-2.5 px-3 border border-gray-300 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 rounded-full outline-none transition-colors"
          disabled={disabled}
        />
        
        <button
          type="submit"
          disabled={!message.trim() || disabled}
          className={`p-2.5 rounded-full ${
            message.trim() && !disabled
              ? 'bg-purple-500 text-white hover:bg-purple-600' 
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          } transition-colors`}
          aria-label="Enviar"
        >
          <Send className="h-5 w-5" />
        </button>
      </form>
    </div>
  );
};

export default MessageInput;