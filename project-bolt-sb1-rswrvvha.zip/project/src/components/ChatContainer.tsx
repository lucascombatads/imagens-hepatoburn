import React, { useState, useEffect, useRef } from 'react';
import MessageInput from './MessageInput';
import MessageList from './MessageList';
import { Message } from '../types/chat';

const ChatContainer: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Olá! Eu sou o GoatMind AI, baseado no GPT-2. Como posso ajudar você hoje?',
      sender: 'ai',
      timestamp: new Date().toISOString()
    }
  ]);
  const [isThinking, setIsThinking] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (text: string) => {
    if (!text.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    // Simulate AI thinking
    setIsThinking(true);
    
    // Simulate AI response after delay
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: `Esta é uma resposta simulada do GPT-2 local para: "${text}"`,
        sender: 'ai',
        timestamp: new Date().toISOString()
      };
      
      setMessages(prev => [...prev, aiResponse]);
      setIsThinking(false);
    }, 1500);
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'welcome',
        text: 'Chat limpo. Como posso ajudar você hoje?',
        sender: 'ai',
        timestamp: new Date().toISOString()
      }
    ]);
  };

  return (
    <main className="flex-1 flex flex-col max-w-4xl w-full mx-auto p-4 overflow-hidden">
      <div className="flex-1 overflow-y-auto mb-4 rounded-lg">
        <MessageList 
          messages={messages} 
          isThinking={isThinking} 
        />
        <div ref={bottomRef} />
      </div>
      <MessageInput 
        onSendMessage={handleSendMessage} 
        onClearChat={handleClearChat} 
        disabled={isThinking} 
      />
    </main>
  );
};

export default ChatContainer;