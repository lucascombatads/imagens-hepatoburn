import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white py-3 px-6 border-t border-gray-200">
      <div className="max-w-4xl mx-auto text-center">
        <p className="text-sm text-gray-500">
          Rodando com GPT-2 localmente
        </p>
      </div>
    </footer>
  );
};

export default Footer;